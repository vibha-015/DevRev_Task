export declare const run: (events: any[]) => Promise<void>;
export default run;
