"use strict";
/*
 * Copyright (c) 2023 DevRev, Inc. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
const function_1_1 = require("../functions/function_1");
describe('Test some function', () => {
    it('Something', () => {
        (0, function_1_1.run)([]);
    });
});
