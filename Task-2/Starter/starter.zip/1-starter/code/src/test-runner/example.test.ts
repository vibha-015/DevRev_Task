/*
 * Copyright (c) 2023 DevRev, Inc. All rights reserved.
 */

import { run } from '../functions/function_1';

describe('Test some function', () => {
  it('Something', () => {
    run([]);
  });
});
