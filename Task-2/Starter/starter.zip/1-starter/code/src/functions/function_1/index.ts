/*
 * Copyright (c) 2023 DevRev, Inc. All rights reserved.
 */

export const run = async (events: any[]) => {
  /*
  Put your code here and remove the log below
  */

  console.info('events', events);
};

export default run;
